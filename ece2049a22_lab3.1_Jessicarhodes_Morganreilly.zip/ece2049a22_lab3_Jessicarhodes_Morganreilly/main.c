#include <msp430.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "peripherals.h"

unsigned int COUNTS_PER_SEC = 200;
#define INTERVAl 163  //0.005 s resolution
unsigned int timer_cnt;
unsigned int time;
unsigned int prev_month = 0;
char intToStr[3];
char floatToStr[5];
unsigned int numButtonPressed = 0;
unsigned int editM = 0;

#define CALADC12_15V_30C  *((unsigned int *)0x1A1A)
// Temperature Sensor Calibration = Reading at 85 degrees C is stored at addr 1A1Ch                                            //See device datasheet for TLV table memory mapping
#define CALADC12_15V_85C  *((unsigned int *)0x1A1C)

unsigned int in_temp;
volatile float temperatureDegC;
float tempReadings[36];
unsigned int numOfReadings = 0;
unsigned int timeDivision[5] = {12, 31, 24, 60, 60};

//structs
struct Date {
   unsigned int month;
   unsigned int day;
   unsigned int  hour;
   unsigned int  min;
   unsigned int  sec;
};
struct Date date;

void initDate() {
    date.month = 0;
    date.day = 1;
    date.hour = 0;
    date.min = 0;
    date.sec = 0;
}

struct Temp {
    float celcius;
    float F;
};
struct Temp temp;

void initTemp() {
    temp.celcius = 0;
    temp.F = 0;
}

//function prototypes
void startTimerA2();
void displayMonth();
void displayDay();
void displayHour();
void displayMin();
void displaySec();
void displayDate();
unsigned int updateMonth(unsigned int month, unsigned int days);
const char* intToString(int num);
const char* intToMonth(unsigned int num);
void displayTemp(float inAvgTempC);
char intToChar(int num);
float readTemp();
char readButtons();
void editSettings();
float getAvgTemp();
unsigned int readScroll();
unsigned int getDivider(unsigned int div);
void stopTimer();


//functions

float readTemp() {
    ADC12CTL0 = ADC12SHT0_9 | ADC12REFON | ADC12ON;     // Internal ref = 1.5V

    ADC12CTL1 = ADC12SHP;                     // Enable sample timer

    // Using ADC12MEM0 to store reading
    ADC12MCTL0 = ADC12SREF_1 + ADC12INCH_10;  // ADC i/p ch A10 = temp sense
    // ACD12SREF_1 = internal ref = 1.5v

    __delay_cycles(100);                    // delay to allow Ref to settle
    ADC12CTL0 |= ADC12ENC;              // Enable conversion

    volatile float degC_per_bit;
    volatile unsigned int bits30, bits85;

    ADC12CTL0 &= ~ADC12SC;      // clear the start bit
    ADC12CTL0 |= ADC12SC;       // Sampling and conversion start
    // Single conversion (single channel)

    // Poll busy bit waiting for conversion to complete
    while (ADC12CTL1 & ADC12BUSY)
        __no_operation();

    in_temp = ADC12MEM0;      // Read in results if conversion

    // Temperature in Celsius. See the Device Descriptor Table section in the
    // System Resets, Interrupts, and Operating Modes, System Control Module
    // chapter in the device user's guide for background information on the
    // formula.

    // Use calibration data stored in info memory
    bits30 = CALADC12_15V_30C;
    bits85 = CALADC12_15V_85C;
    degC_per_bit = ((float)(85.0 - 30.0))/((float)(bits85-bits30));


    return (float)((long) in_temp - CALADC12_15V_30C) * degC_per_bit +30.0;
}

void startTimerA2() {
    TA2CTL = TASSEL_1 + MC_1 + ID_0;
    TA2CCR0 = INTERVAl; //
    TA2CCTL0 = CCIE;
}

#pragma vector=TIMER2_A0_VECTOR
    __interrupt void TimerA2_ISR() {
        timer_cnt++;

        if((timer_cnt % COUNTS_PER_SEC) == 0)
        {
            date.sec++;
            if(date.sec >= 61) {
                date.min++;
                date.sec = 0;
            }
            if(date.min >= 61) {
                date.min = 0;
                date.hour++;
            }
            if(date.hour >= 24) {
                date.day++;
                date.hour = 0;
            }
            if(date.day >= 28 && updateMonth(date.month, date.day)){
                date.month++;
                date.day = 1;
            }
        }
    }

void stopTimer() {
    TA2CTL = MC_0;
    TA2CCTL0 &= ~CCIE;
    timer_cnt = 0;
    time = 0;
}

void displayMonth(){
    Graphics_drawStringCentered(&g_sContext, intToMonth(date.month), AUTO_STRING_LENGTH, 44, 25, TRANSPARENT_TEXT);
}
void displayDay(){
    Graphics_drawStringCentered(&g_sContext, intToString(date.day), AUTO_STRING_LENGTH, 60, 25, TRANSPARENT_TEXT);
}
void displayHour(){
    Graphics_drawStringCentered(&g_sContext, intToString(date.hour), AUTO_STRING_LENGTH, 28, 40, TRANSPARENT_TEXT);
    Graphics_drawStringCentered(&g_sContext, " : ", AUTO_STRING_LENGTH, 38, 40, TRANSPARENT_TEXT);
    Graphics_drawStringCentered(&g_sContext, " : ", AUTO_STRING_LENGTH, 58, 40, TRANSPARENT_TEXT);
}
void displayMin(){
    Graphics_drawStringCentered(&g_sContext, intToString(date.min), AUTO_STRING_LENGTH, 48, 40, TRANSPARENT_TEXT);
}
void displaySec(){
    Graphics_drawStringCentered(&g_sContext, intToString(date.sec), AUTO_STRING_LENGTH, 68, 40, TRANSPARENT_TEXT);
}

void displayDate() {
    Graphics_clearDisplay(&g_sContext); // Clear the display

    // Write some text to the display
    Graphics_drawStringCentered(&g_sContext, intToMonth(date.month), AUTO_STRING_LENGTH, 44, 25, TRANSPARENT_TEXT);
    Graphics_drawStringCentered(&g_sContext, intToString(date.day), AUTO_STRING_LENGTH, 60, 25, TRANSPARENT_TEXT);
    Graphics_drawStringCentered(&g_sContext, intToString(date.hour), AUTO_STRING_LENGTH, 28, 40, TRANSPARENT_TEXT);
    Graphics_drawStringCentered(&g_sContext, " : ", AUTO_STRING_LENGTH, 38, 40, TRANSPARENT_TEXT);
    Graphics_drawStringCentered(&g_sContext, intToString(date.min), AUTO_STRING_LENGTH, 48, 40, TRANSPARENT_TEXT);
    Graphics_drawStringCentered(&g_sContext, " : ", AUTO_STRING_LENGTH, 58, 40, TRANSPARENT_TEXT);
    Graphics_drawStringCentered(&g_sContext, intToString(date.sec), AUTO_STRING_LENGTH, 68, 40, TRANSPARENT_TEXT);
}

const char* intToString(int num) {
    sprintf(intToStr, "%d", num);
    return intToStr;
}

char intToChar(int num) {
    return num + '0';
}

const char* floatToString(float fnum) {
    float remain = 0;

    // converts the hundreds place
    unsigned int hundreds = fnum / 100;
    remain = fnum - (hundreds * 100);

    // converts the tens place
    unsigned int tens = remain / 10;
    remain = remain - (tens*10);

    // converts the ones place
    unsigned int ones = floor(remain);
    remain = remain - ones;

    // converts the tenths place
    unsigned int tenths = floor(remain * 10);

    floatToStr[0] = intToChar(hundreds);
    floatToStr[1] = intToChar(tens);
    floatToStr[2] = intToChar(ones);
    floatToStr[3] = '.';
    floatToStr[4] = intToChar(tenths);

    return floatToStr;
}


const char* intToMonth(unsigned int num) {
    unsigned int month = num % 12;
    switch(month) {

    case 0:
        return "JAN";
    case 1:
        return "FEB";
    case 2:
        return "MAR";
    case 3:
        return "APR";
    case 4:
        return "MAY";
    case 5:
        return "JUN";
    case 6:
        return "JUL";
    case 7:
        return "AUG";
    case 8:
        return "SEP";
    case 9:
        return "OCT";
    case 10:
        return "NOV";
    case 11:
        return "DEC";
    }
    return "";
}

unsigned int updateMonth(unsigned int month, unsigned int days) {
    if((month == 0 || month == 2 || month == 4 || month == 6 || month == 7 || month == 9 || month == 11 ) && days == 32) {
        // returns true if it is one of the months with 31 days
        return 1;
    } else if((month == 3 || month == 5 || month == 8 || month == 10) && days == 31) {
        // months with 30 days
        return 1;
    } else if(month == 1 && days == 29) {
        return 1;
    }
    return 0;
}

void displayTemp(float inAvgTempC) {
    temp.celcius = inAvgTempC;
    temp.F = (9.0/5.0) * inAvgTempC + 32.0;

    Graphics_drawStringCentered(&g_sContext, floatToString(temp.celcius), AUTO_STRING_LENGTH, 48, 60, TRANSPARENT_TEXT);
    Graphics_drawStringCentered(&g_sContext, floatToString(temp.F), AUTO_STRING_LENGTH, 48, 70, TRANSPARENT_TEXT);
}

float getAvgTemp() {
    float tempCollector = 0;
    int i;
    for(i = 0; i < 36; i++) {
        tempCollector += tempReadings[i];
    }
    return tempCollector / 36.0;
}

char readButtons() {
    // Button S1: 7.0 and S4: 7.4 (these are configured correctly)
    P7SEL &= ~(BIT0 | BIT4);
    P7DIR &= ~(BIT0 | BIT4);
    P7REN |=  (BIT0 | BIT4);
    P7OUT |=  (BIT0 | BIT4);

    char x;
    char v;

    x = (~(P7IN) & (BIT0));        //Button S1  7.0  Enables Editing State
    v = ~(P7IN) & (BIT4);         //Button S4   7.4  Disables Editing and Saves Settings

    char outbits = (x | v);
    return outbits;
}

void editSettings() {
    while(!(readButtons() & BIT4)) {
        Graphics_clearDisplay(&g_sContext); // Clear the display
        unsigned int set = numButtonPressed - 1;
        switch(set) {

        case 0:
            date.month = readScroll() / getDivider(timeDivision[set]);
            displayMonth();
            break;
        case 1:
            date.day = readScroll() / getDivider(timeDivision[set]);
            displayMonth();
            displayDay();
            break;
        case 2:
            date.hour = readScroll() / getDivider(timeDivision[set]);
            displayHour();
            break;
        case 3:
            date.min = readScroll() / getDivider(timeDivision[set]);
            displayHour();
            displayMin();
            break;
        case 4:
            date.sec = readScroll() / getDivider(timeDivision[set]);
            displayHour();
            displayMin();
            displaySec();
            break;
        }
        Graphics_flushBuffer(&g_sContext); // update screen
        if(readButtons() & BIT0) {
            numButtonPressed++;
        }
        if(numButtonPressed >=6){
            numButtonPressed = 1;
        }
    }
}

unsigned int readScroll() {

        ADC12CTL0 = ADC12SHT0_9 | ADC12ON;     // No internal reference needed
        ADC12CTL1 = ADC12SHP;                     // Enable sample timer

        // Using ADC12MEM0 to store reading
        ADC12MCTL0 = ADC12SREF_0 + ADC12INCH_0;  // ADC i/p ch A0 = scroll wheel
                                                       // ACD12SREF_0 = AVCC 3.3v
        __delay_cycles(100);                    // delay to allow Ref to settle

        ADC12CTL0 |= ADC12ENC;              // Enable conversion
        ADC12CTL0 &= ~ADC12SC;          // clear the start bit

        ADC12CTL0 |= ADC12SC;       // Sampling and conversion start
                                    // Single conversion (single channel)
        while (ADC12CTL1 & ADC12BUSY)
            __no_operation();

        unsigned int scrollWheelADC = ADC12MEM0 & 0x0FFF;  //Read in results if conversion

       return scrollWheelADC;
}

unsigned int getDivider(unsigned int div) {
    return 4095 / div;
}

int main() {

    WDTCTL = WDTPW | WDTHOLD;    // Stop watchdog timer. Always need to stop this!!
    //enable_interrupt();
    _BIS_SR(GIE);

    REFCTL0 &= ~REFMSTR;     // Reset REFMSTR to hand over control of
    // internal reference voltages to
    // ADC12_A control registers

    P6SEL |= BIT0;  // sets pin 0 for port 6 as function mode

    initDate();
    startTimerA2();
    configDisplay();
    displayDate();

    while(1) {

        if(readButtons() & BIT0) {
            stopTimer();
            editSettings();
            startTimerA2();
        }

        if((timer_cnt % COUNTS_PER_SEC) == 0) {

            temperatureDegC = readTemp();
            tempReadings[numOfReadings % 36] = temperatureDegC;
            numOfReadings++;

            volatile float tempToDisplay = (numOfReadings < 36) ? temperatureDegC : (getAvgTemp());

            displayDate();
            displayTemp(tempToDisplay);
            Graphics_flushBuffer(&g_sContext); // update screen
        }
    }
}
