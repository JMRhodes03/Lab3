/************** ECE2049 DEMO CODE ******************/
/**************  25 August 2021   ******************/
/***************************************************/

#include <msp430.h>



/* Peripherals.c and .h are where the functions that implement
 * the LEDs and keypad, etc are. It is often useful to organize
 * your code by putting like functions together in files.
 * You include the header associated with that file(s)
 * into the main file of your project. */
#include "peripherals.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define CALADC12_15V_85C  *((unsigned int *)0x1A1C)
#define CALADC12_15V_30C  *((unsigned int *)0x1A1A)


unsigned int in_temp;

//Globals
void swDelay(char numLoops);
void avgTemp(float temperatureDegC, float temperatureDegF);
char displayTemp(float inAvgTempC, float inAvgTempF);
char displayDate(unsigned char month[], unsigned int day);
unsigned char month[3] = "MMM";
unsigned int day = 00;
long unsigned int timeC = 0;
unsigned int in_temp;
unsigned int in_value;


// Main
int main(void){
    volatile float temperatureDegC;
    volatile float temperatureDegF;
    volatile float degC_per_bit;
    volatile unsigned int bits30, bits85;

    WDTCTL = WDTPW + WDTHOLD;                           // Stop WDT

    P8SEL &= ~BIT0;                                     // Configure P8.0 as digital IO output and set it to 1
    P8DIR |= BIT0;                                      // This supplied 3.3 volts across scroll wheel potentiometer
    P8OUT |= BIT0;                                      // See schematic at end or MSP-EXP430F5529 board users guide

    REFCTL0 &= ~REFMSTR;                                // Reset REFMSTR to hand over control of internal reference voltages to ADC12_A control registers
    ADC12CTL0 = ADC12SHT0_9 | ADC12REFON | ADC12ON;     // Internal ref = 1.5V
    ADC12CTL1 = ADC12SHP;                               // Enable sample timer
    ADC12MCTL0 = ADC12SREF_0 + ADC12INCH_5;             // Use ADC12MEM0 register for conversion results ADC12INCH5 = Scroll wheel = A5, ACD12SREF_0 = Vref+ = Vcc
    ADC12MCTL0 = ADC12SREF_1 + ADC12INCH_10;            // Using ADC12MEM0 to store reading ADC i/p ch A10 = temp sense ACD12SREF_1 = internal ref = 1.5v

    __delay_cycles(100);                                // delay to allow Ref to settle

    ADC12CTL0 |= ADC12ENC;                              // Enable conversion

    //Use calibration data stored in info memory
    bits30 = CALADC12_15V_30C;
    bits85 = CALADC12_15V_85C;
    degC_per_bit = ((float)(85.0 - 30.0))/((float)(bits85-bits30));

  while(1)
  {
    ADC12CTL0 &= ~ADC12SC;                  // clear the start bit
    ADC12CTL0 |= ADC12SC;                   // Sampling and conversion start
                                            // Single conversion (single channel)

                                            // Poll busy bit waiting for conversion to complete
    while (ADC12CTL1 & ADC12BUSY)
        __no_operation();
    in_value = ADC12MEM0;                   // Read results if conversion done
    in_temp = ADC12MEM0;                    // Read in results if conversion

    // Temperature in Celsius. See the Device Descriptor Table section in the
    // System Resets, Interrupts, and Operating Modes, System Control Module
    // chapter in the device user's guide for background information on the
    // formula.
    temperatureDegC = (float)((long)in_temp - CALADC12_15V_30C) * degC_per_bit +30.0;
    // Temperature in Fahrenheit
    temperatureDegF = ((temperatureDegC * 1.8) + 32);       // F = (C*1.8) + 32 => C->F conversion

    __no_operation();                       // SET BREAKPOINT HERE
  }
}

void swDelay(char numLoops){
    volatile unsigned int i,j;              // volatile to prevent removal in optimization
                                            // by compiler. Functionally this is useless code

    for (j=0; j<numLoops; j++)
    {
        i = 50000 ;                         // SW Delay
        while (i > 0)                       // could also have used while (i)
            i--;
    }
}

void avgTemp(float temperatureDegC, float temperatureDegF){
    float inAvgTempC = temperatureDegC;
    float inAvgTempF = temperatureDegF;

    return inAvgTempC, inAvgTempF;
}

char displayTemp(float inAvgTempC, float inAvgTempF){
    char tempC[3];
        tempC[0] = inAvgTempC;
        tempC[1] = 'C';
        tempC[2] = '\0';

    char tempF[3];
        tempF[0] = inAvgTempF;
        tempF[1] = 'F';
        tempF[2] = '\0';

    Graphics_drawStringCentered(&g_sContext, tempC, AUTO_STRING_LENGTH, 48, 25, TRANSPARENT_TEXT);
    Graphics_drawStringCentered(&g_sContext, tempF, AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
}

char displayDate(unsigned char month[], unsigned int day){
    char date[6];
        date[0] = month[0];
        date[1] = month[1];
        date[2] = month[2];
        date[3] = ' ';
        date[4] = day;
        date[5] = '\0';

    return date;
}
























